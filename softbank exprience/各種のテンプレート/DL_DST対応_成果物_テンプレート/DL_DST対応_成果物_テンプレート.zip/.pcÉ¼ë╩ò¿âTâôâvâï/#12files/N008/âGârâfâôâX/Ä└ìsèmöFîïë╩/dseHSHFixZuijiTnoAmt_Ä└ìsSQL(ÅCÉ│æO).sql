SELECT
    wg.bill_group_id
    , wg.multipurpose_bill_kbn
    , wg.form_ptn
    , wg.send_cycle_id
    , wg.issue_sequence
    , wg.payment_lmt_date
    , wg.cvs_use_lmt_date
    , wg.call_stop_plan_date
    , wg.ctt_cancel_plan_date
    , wg.trgt_period_from
    , wg.trgt_period_to
    , wg.bill_month1
    , wg.bill_price1
    , wg.bill_month2
    , wg.bill_price2
    , wg.bill_month3
    , wg.bill_price3
    , wg.bill_month4
    , wg.bill_price4
    , wg.before_bill_price
    , wg.use_price
    , wg.payment_price
    , wg.bill_price_total
    , to_char(wg.create_tmstmp, 'YYYYMMDDHH24MISSFF')
    , to_char(wg.last_upd_tmstmp, 'YYYYMMDDHH24MISSFF')
    , wg.last_upd_charge_id
    , wg.last_upd_charge_name
    , NVL(sb.bill_month, '999912')
    , NVL( 
        to_char(sb.last_upd_tmstmp, 'YYYYMMDDHH24MISSFF')
        , '0'
    ) 
FROM
    dse_w_generalbills wg
    , dse_s_billgroupmanage sb
    , dse_d_dunningbasic db 
WHERE
    ( 
        wg.multipurpose_bill_kbn = 3 
        OR wg.multipurpose_bill_kbn = 0
    ) 
    AND wg.bill_group_id = db.bill_group_id(+) 
    AND db.demand_manage_cycle_id = sb.send_cycle_id(+) 
    AND sb.bill_cycle_id(+) = '05' 
    AND sb.previous_month_ind(+) = 'N'

